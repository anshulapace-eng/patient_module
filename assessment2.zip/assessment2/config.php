<?php
$mysqli = new mysqli("localhost", "root", "", "vim_acadmic");

if ($mysqli->connect_errno) {
    die("DB Connection failed: " . $mysqli->connect_error);
}

$conn = $mysqli;
?>